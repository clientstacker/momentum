const enc = new TextEncoder();
const hex = b => [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
const rnd = n => hex(crypto.getRandomValues(new Uint8Array(n)));
const json = (d, s = 200, h = {}) => new Response(JSON.stringify(d), { status: s, headers: { 'content-type': 'application/json', ...h } });
const fail = (m, s = 400) => json({ error: m }, s);

async function hash(pw, salt) {
  const k = await crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']);
  return hex(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: 100000 }, k, 256));
}

async function start(db, userId) {
  const t = rnd(24);
  await db.prepare('INSERT INTO sessions VALUES(?1,?2,?3)').bind(t, userId, Date.now() + 2592e6).run();
  return json({ ok: true }, 200, { 'set-cookie': `s=${t}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=2592000` });
}

export async function onRequest({ request, env, params }) {
  const db = env.DB, m = request.method;
  const [res, rid, act] = params.path || [];
  const id = +rid;
  const b = m === 'GET' || m === 'DELETE' ? {} : await request.json().catch(() => ({}));

  if (res === 'signup' && m === 'POST') {
    const email = String(b.email || '').trim().toLowerCase(), pw = String(b.password || '');
    if (!/^\S+@\S+\.\S+$/.test(email)) return fail('Enter a valid email');
    if (pw.length < 8) return fail('Password needs at least 8 characters');
    const salt = rnd(16);
    try {
      const r = await db.prepare('INSERT INTO users(email,name,pw,salt,created) VALUES(?1,?2,?3,?4,?5)')
        .bind(email, String(b.name || '').trim().slice(0, 40), await hash(pw, salt), salt, Date.now()).run();
      return start(db, r.meta.last_row_id);
    } catch { return fail('That email already has an account', 409); }
  }
  if (res === 'login' && m === 'POST') {
    const u = await db.prepare('SELECT id,pw,salt FROM users WHERE email=?1').bind(String(b.email || '').trim().toLowerCase()).first();
    if (!u || await hash(String(b.password || ''), u.salt) !== u.pw) return fail('Wrong email or password', 401);
    return start(db, u.id);
  }

  const c = (request.headers.get('cookie') || '').match(/(?:^|; )s=([a-f0-9]+)/);
  const s = c && await db.prepare('SELECT user_id FROM sessions WHERE token=?1 AND expires>?2').bind(c[1], Date.now()).first();
  if (!s) return fail('Not signed in', 401);
  const uid = s.user_id;
  const own = t => db.prepare(`SELECT id FROM ${t} WHERE id=?1 AND user_id=?2`).bind(id, uid).first();

  if (res === 'logout') {
    await db.prepare('DELETE FROM sessions WHERE token=?1').bind(c[1]).run();
    return json({ ok: true }, 200, { 'set-cookie': 's=; Path=/; Max-Age=0' });
  }
  if (res === 'me') return json(await db.prepare('SELECT name,email FROM users WHERE id=?1').bind(uid).first());

  if (res === 'journal') {
    if (m === 'GET') return json((await db.prepare('SELECT id,kind,day,mood,body FROM journal WHERE user_id=?1 ORDER BY id DESC LIMIT 60').bind(uid).all()).results);
    if (m === 'POST') {
      const body = String(b.body || '').trim().slice(0, 5000);
      if (!body) return fail('Write something first');
      await db.prepare('INSERT INTO journal(user_id,kind,day,mood,body,created) VALUES(?1,?2,?3,?4,?5,?6)')
        .bind(uid, b.kind === 'gratitude' ? 'gratitude' : 'journal', String(b.day).slice(0, 10), Math.min(5, Math.max(1, +b.mood || 3)), body, Date.now()).run();
      return json({ ok: true });
    }
    if (m === 'DELETE') { await db.prepare('DELETE FROM journal WHERE id=?1 AND user_id=?2').bind(id, uid).run(); return json({ ok: true }); }
  }

  if (res === 'habits') {
    if (m === 'GET') {
      const rows = (await db.prepare("SELECT h.id,h.name,COALESCE(group_concat(l.day),'') days FROM habits h LEFT JOIN habit_logs l ON l.habit_id=h.id WHERE h.user_id=?1 GROUP BY h.id ORDER BY h.id").bind(uid).all()).results;
      return json(rows.map(h => ({ ...h, days: h.days ? h.days.split(',') : [] })));
    }
    if (m === 'POST' && !rid) {
      const n = String(b.name || '').trim().slice(0, 60);
      if (!n) return fail('Name your habit');
      await db.prepare('INSERT INTO habits(user_id,name,created) VALUES(?1,?2,?3)').bind(uid, n, Date.now()).run();
      return json({ ok: true });
    }
    if (m === 'POST' && act === 'toggle') {
      if (!await own('habits')) return fail('Not found', 404);
      const d = String(b.day).slice(0, 10);
      const r = await db.prepare('DELETE FROM habit_logs WHERE habit_id=?1 AND day=?2').bind(id, d).run();
      if (!r.meta.changes) await db.prepare('INSERT INTO habit_logs VALUES(?1,?2)').bind(id, d).run();
      return json({ ok: true });
    }
    if (m === 'DELETE') {
      if (!await own('habits')) return fail('Not found', 404);
      await db.batch([db.prepare('DELETE FROM habit_logs WHERE habit_id=?1').bind(id), db.prepare('DELETE FROM habits WHERE id=?1').bind(id)]);
      return json({ ok: true });
    }
  }

  if (res === 'goals') {
    if (m === 'GET') return json((await db.prepare('SELECT id,title,done FROM goals WHERE user_id=?1 ORDER BY done,id').bind(uid).all()).results);
    if (m === 'POST' && !rid) {
      const t = String(b.title || '').trim().slice(0, 120);
      if (!t) return fail('Name your goal');
      await db.prepare('INSERT INTO goals(user_id,title,created) VALUES(?1,?2,?3)').bind(uid, t, Date.now()).run();
      return json({ ok: true });
    }
    if (m === 'POST' && act === 'toggle') { await db.prepare('UPDATE goals SET done=1-done WHERE id=?1 AND user_id=?2').bind(id, uid).run(); return json({ ok: true }); }
    if (m === 'DELETE') { await db.prepare('DELETE FROM goals WHERE id=?1 AND user_id=?2').bind(id, uid).run(); return json({ ok: true }); }
  }

  return fail('Not found', 404);
}
