# Momentum — motivational app

Bold, energetic daily motivation: quote of the day, affirmation, journal and gratitude entries with mood, habit streaks, and goals. Accounts from day one. Runs on Cloudflare Pages + Functions + D1.

## Deploy

1. Create the database and copy the `database_id` it prints into `wrangler.toml`:
   ```
   npx wrangler d1 create motivation-db
   ```
2. Create the tables:
   ```
   npx wrangler d1 execute motivation-db --remote --file=schema.sql
   ```
3. Push this folder to a new GitHub repo.
4. In the Cloudflare dashboard: Workers & Pages → Create → Pages → Connect to Git → pick the repo.
   Build command: leave empty. Build output directory: `public`.
5. Deploy. Every push to `main` redeploys automatically.

## Local dev

```
npx wrangler d1 execute motivation-db --local --file=schema.sql
npx wrangler pages dev public --d1=DB
```

## Layout

- `public/index.html` — the whole front end (no build step)
- `functions/api/[[path]].js` — auth and API (sign-up, login, journal, habits, goals)
- `schema.sql` — D1 tables

## Next up

Favorite quotes, breathing and focus timer, reminders, progress charts and badges, and a move to React once the features settle.
